'use client'
import React from 'react'

export default function ThreeGlobe() {
  const ref = React.useRef<HTMLDivElement>(null)
  const [ready, setReady] = React.useState(false)

  React.useEffect(() => {
    let disposed = false
    ;(async () => {
      try {
        const THREE = await import('three')
        if (disposed || !ref.current) return
        const el = ref.current
        const scene = new THREE.Scene()
        const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 1000)
        camera.position.z = 2.2
        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
        renderer.setSize(el.clientWidth, el.clientHeight)
        el.appendChild(renderer.domElement)
        const sphere = new THREE.Mesh(
          new THREE.SphereGeometry(1, 64, 64),
          new THREE.MeshPhongMaterial({ color: 0x114466, shininess: 8 })
        )
        scene.add(sphere)
        const light = new THREE.DirectionalLight(0xffffff, 1.1)
        light.position.set(5, 5, 5)
        scene.add(light)
        const obs = new ResizeObserver(() => {
          const s = el.getBoundingClientRect()
          renderer.setSize(s.width, s.height)
        })
        obs.observe(el)
        ;(function anim() {
          if (disposed) return
          sphere.rotation.y += 0.0025
          renderer.render(scene, camera)
          requestAnimationFrame(anim)
        })()
        setReady(true)
        return () => {
          disposed = true
          obs.disconnect()
          renderer.dispose()
        }
      } catch {
        setReady(false)
      }
    })()
    return () => { disposed = true }
  }, [])

  return (
    <div ref={ref} className="globe" aria-label="Three.js globe">
      {!ready && (<span className="small" style={{ position: 'absolute', bottom: 8, left: 8, opacity: 0.7 }}>Fallback globe</span>)}
    </div>
  )
}
