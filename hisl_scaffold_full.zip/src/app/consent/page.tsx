'use client'
export default function ConsentPage() {
  const receipt = { version: '1.0', issuedAt: new Date().toISOString(), consents: [{ purpose: 'demo_assessment', status: 'granted', scope: ['demo'], expiry: null }] }
  const download = () => {
    const b = new Blob([JSON.stringify(receipt, null, 2)], { type: 'application/json' })
    const u = URL.createObjectURL(b)
    const a = document.createElement('a')
    a.href = u
    a.download = 'consent-receipt.json'
    a.click()
    URL.revokeObjectURL(u)
  }
  return (
    <div className="container section">
      <h2>Consent & Receipts</h2>
      <button className="btn" onClick={download}>Download Consent Receipt</button>
    </div>
  )
}
