'use client'
import React from 'react'
import dynamic from 'next/dynamic'

const ThreeGlobe = dynamic(() => import('../../../src/lib/three-globe').then(m => m.default), {
  ssr: false,
  loading: () => <div className="globe" />
})

export default function GlobePage() {
  return (
    <div className="container section">
      <h2>Global Prompt Journey — IntegAI Simulation</h2>
      <ThreeGlobe />
    </div>
  )
}
