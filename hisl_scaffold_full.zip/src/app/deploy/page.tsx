'use client'
export default function DeployPage() {
  async function submit(e: any) {
    e.preventDefault()
    const fd = new FormData(e.target)
    const sector = String(fd.get('sector') || 'demo')
    const company = String(fd.get('company') || 'ACME')
    await fetch('/api/ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        runId: crypto.randomUUID(),
        messages: [{ role: 'user', content: `Assessment for ${company} in ${sector}` }],
        agency_level: 'review_window',
        consent_token: 'demo',
        metadata: { promptHash: 'assessment', data_class: 'demo', sector }
      })
    })
    alert('Assessment submitted (Simulation Mode).')
  }
  return (
    <div className="container section">
      <h2>Deployment Platform — Assessment</h2>
      <form onSubmit={submit} className="panel" style={{ display: 'grid', gap: 12 }}>
        <label>Company
          <input name="company" required style={{ padding:'10px', borderRadius:10, border:'1px solid rgba(255,255,255,.15)', background:'rgba(255,255,255,.02)', color:'var(--text)' }}/>
        </label>
        <label>Sector
          <input name="sector" required style={{ padding:'10px', borderRadius:10, border:'1px solid rgba(255,255,255,.15)', background:'rgba(255,255,255,.02)', color:'var(--text)' }}/>
        </label>
        <button className="btn primary" type="submit">Submit Assessment</button>
      </form>
    </div>
  )
}
